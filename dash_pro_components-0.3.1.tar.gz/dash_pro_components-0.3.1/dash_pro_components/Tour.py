# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Tour(Component):
    """A Tour component.


Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- accentColor (string; default "var(--accent, #007aff)"):
    Custom CSS string designating the color of the accent. By default,
    it will use the same color as the theme editor's accent.

- className (string; default "ddkProTourDefault"):
    Custom class name that can be assigned for custom CSS. The default
    value, \"ddkProTourDefault\", ensures that the component can be
    controlled by the theme editor.

- isOpen (boolean; default False):
    Whether the component is currently open.

- steps (list of dicts; optional):
    All the steps.

    `steps` is a list of dicts with keys:

    - content (a list of or a singular dash component, string or number | dash component; required):
        Content to be rendered inside Tour card.

    - position (list of numbers | a value equal to: 'top', 'right', 'bottom', 'left', 'center'; optional):
        Tour relative position.

    - selector (string; optional):
        Component CSS selector.

    - stepInteraction (boolean; optional):
        Set if interaction is available for this specific step.

    - style (dict; optional):
        CSS properties."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, className=Component.UNDEFINED, accentColor=Component.UNDEFINED, steps=Component.UNDEFINED, isOpen=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'accentColor', 'className', 'isOpen', 'steps']
        self._type = 'Tour'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'accentColor', 'className', 'isOpen', 'steps']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Tour, self).__init__(**args)
