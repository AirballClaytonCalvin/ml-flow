# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class CodeTextarea(Component):
    """A CodeTextarea component.


Keyword arguments:

- id (string; optional)

- className (string; optional):
    Additional class name.

- code (string; optional)

- language (string; default 'python')

- minHeight (number; default 16):
    The minimum height (in px) of the editor. Default: `16`.

- padding (number; default 15):
    Optional padding for code. Default: `10`.

- placeholder (string; default '')

- style (dict; default {  fontSize: 12,  backgroundColor: "#f5f5f5",  fontFamily: 'ui-monospace,SFMono-Regular,SF Mono,Consolas,Liberation Mono,Menlo,monospace',}):
    CSS properties."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, placeholder=Component.UNDEFINED, language=Component.UNDEFINED, padding=Component.UNDEFINED, minHeight=Component.UNDEFINED, code=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'className', 'code', 'language', 'minHeight', 'padding', 'placeholder', 'style']
        self._type = 'CodeTextarea'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'className', 'code', 'language', 'minHeight', 'padding', 'placeholder', 'style']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(CodeTextarea, self).__init__(**args)
