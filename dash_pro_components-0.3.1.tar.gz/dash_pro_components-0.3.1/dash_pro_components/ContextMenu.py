# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class ContextMenu(Component):
    """A ContextMenu component.


Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    The MenuItem or SubMenu components.

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- className (string; optional):
    Additional class name.

- hideOnLeave (boolean; optional):
    Hides the context menu on mouse leave.

- lastMenuId (string; optional):
    The id of the menu that was most recently clicked.

- preventHideOnContextMenu (boolean; optional):
    Prevents hiding of the context menu on contextMenu event.

- preventHideOnResize (boolean; optional):
    Prevents hiding of the context menu on resize event.

- preventHideOnScroll (boolean; optional):
    Prevents hiding of the context menu on scroll event.

- style (dict; optional):
    CSS properties."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, hideOnLeave=Component.UNDEFINED, preventHideOnContextMenu=Component.UNDEFINED, preventHideOnResize=Component.UNDEFINED, preventHideOnScroll=Component.UNDEFINED, lastMenuId=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'hideOnLeave', 'lastMenuId', 'preventHideOnContextMenu', 'preventHideOnResize', 'preventHideOnScroll', 'style']
        self._type = 'ContextMenu'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'hideOnLeave', 'lastMenuId', 'preventHideOnContextMenu', 'preventHideOnResize', 'preventHideOnScroll', 'style']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(ContextMenu, self).__init__(children=children, **args)
