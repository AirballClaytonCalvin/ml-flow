# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Gantt(Component):
    """A Gantt component.


Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- arrow_curve (number; default 5):
    The arrow curve in pixels.

- autosize_columns (boolean; default True):
    Boolean option to autosize columns based on view_mode.

- bar_corner_radius (number; default 3):
    The bar corner radius in pixels.

- bar_height (number; default 20):
    The bar height in pixels.

- bottom_height (number; default 70):
    Bottom height in pixels.

- className (string; optional):
    Additional class name.

- clickedTask (dict; optional):
    Read-only prop. This is updated when the user double-clicks on a
    task.

- column_width (number; default 30):
    The column width in pixels.

- date_format (string; default 'YYYY-MM-DD')

- gantt_end (string; optional)

- gantt_start (string; optional)

- header_height (number; default 50):
    The header height in pixels.

- padding (number; default 18):
    The padding in pixels.

- popup_trigger (a value equal to: 'click', 'dblclick', 'mouseover'; default 'click'):
    The event that triggers the popup to appear.

- progress_draggable (boolean; default True):
    Whether the user can change the progress of a task.

- style (dict; optional):
    CSS properties.

- task_draggable (boolean; default True):
    Whether the user can modify the start and end time of a task.

- tasks (list of dicts; optional):
    A list of dictionaries, each describing a task.

    `tasks` is a list of dicts with keys:

    - dependencies (string | list; optional):
        The `id` of another task that you want to link by an arrow.

    - end (string; required):
        The end time of the event. Use a datetime.datetime object.

    - id (string; required):
        Needed to reference this task from other tasks.

    - name (string; required):
        The label indicated on the screen.

    - popup_content (string; optional):
        html or markdown string to be rendered inside popup.

    - popup_style (dict; optional):
        Object representing popup inline style.

    - popup_type (string; optional):
        String representing popup type. (html or markdown).

    - progress (number; required):
        A number indicating the progress of the project.

    - start (string; required):
        The start time of the event. Use a datetime.datetime object.

- updatedTask (dict; optional):
    Read-only prop. This is updated when the start, end, or progress
    of a task is changed by the user.

- use_custom_popup (boolean; default False)

- view_mode (a value equal to: 'Hour', 'Quarter Day', 'Half Day', 'Day', 'Week', 'Month', 'Year'; default 'Day'):
    View mode determines the time interval in the Gantt chart."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, tasks=Component.UNDEFINED, updatedTask=Component.UNDEFINED, clickedTask=Component.UNDEFINED, header_height=Component.UNDEFINED, column_width=Component.UNDEFINED, autosize_columns=Component.UNDEFINED, bar_height=Component.UNDEFINED, bar_corner_radius=Component.UNDEFINED, arrow_curve=Component.UNDEFINED, padding=Component.UNDEFINED, date_format=Component.UNDEFINED, view_mode=Component.UNDEFINED, gantt_start=Component.UNDEFINED, gantt_end=Component.UNDEFINED, use_custom_popup=Component.UNDEFINED, popup_trigger=Component.UNDEFINED, progress_draggable=Component.UNDEFINED, task_draggable=Component.UNDEFINED, bottom_height=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'arrow_curve', 'autosize_columns', 'bar_corner_radius', 'bar_height', 'bottom_height', 'className', 'clickedTask', 'column_width', 'date_format', 'gantt_end', 'gantt_start', 'header_height', 'padding', 'popup_trigger', 'progress_draggable', 'style', 'task_draggable', 'tasks', 'updatedTask', 'use_custom_popup', 'view_mode']
        self._type = 'Gantt'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'arrow_curve', 'autosize_columns', 'bar_corner_radius', 'bar_height', 'bottom_height', 'className', 'clickedTask', 'column_width', 'date_format', 'gantt_end', 'gantt_start', 'header_height', 'padding', 'popup_trigger', 'progress_draggable', 'style', 'task_draggable', 'tasks', 'updatedTask', 'use_custom_popup', 'view_mode']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Gantt, self).__init__(**args)
