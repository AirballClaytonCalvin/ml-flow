# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class FlowBackground(Component):
    """A FlowBackground component.
Child component of FlowChart

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- className (string; optional):
    Additional class name.

- color (string; optional):
    the color of the dots or lines - default: #81818a for dots, #eee
    for lines.

- gap (number; default 16):
    the gap between the dots or lines.

- size (number; default 0.5):
    the radius of the dots or the stroke width of the lines.

- style (dict; optional):
    CSS properties.

- variant (string; default "dots"):
    has to be 'dots' or 'lines'."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, variant=Component.UNDEFINED, gap=Component.UNDEFINED, size=Component.UNDEFINED, color=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'className', 'color', 'gap', 'size', 'style', 'variant']
        self._type = 'FlowBackground'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'className', 'color', 'gap', 'size', 'style', 'variant']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(FlowBackground, self).__init__(**args)
