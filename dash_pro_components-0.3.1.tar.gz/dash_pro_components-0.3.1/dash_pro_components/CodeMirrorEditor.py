# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class CodeMirrorEditor(Component):
    """A CodeMirrorEditor component.


Keyword arguments:

- id (string; optional)

- className (string; optional):
    Additional class name.

- code (string; optional)

- language (string; default 'python')

- placeholder (string; default 'Enter the code')

- style (dict; optional):
    CSS properties.

- theme (string; default 'dark')"""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, language=Component.UNDEFINED, code=Component.UNDEFINED, placeholder=Component.UNDEFINED, theme=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'className', 'code', 'language', 'placeholder', 'style', 'theme']
        self._type = 'CodeMirrorEditor'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'className', 'code', 'language', 'placeholder', 'style', 'theme']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(CodeMirrorEditor, self).__init__(**args)
