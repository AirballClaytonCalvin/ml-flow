# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class MenuItem(Component):
    """A MenuItem component.


Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    The children of MenuItem can be a dash component (e.g. a
    `html.Div` or `html.P`).

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- className (string; optional):
    Additional class name.

- clickData (dict; optional):
    Read-only prop. Fires a callback with the `data` attribute of the
    MenuItem that was clicked.

- data (dict; optional):
    The extra data (if required) to be passed to clickData.

- disabled (boolean; default False):
    If True, disables the click event and adds .disabled class.

- divider (boolean; optional):
    Creates a divider instead of a MenuItem when set to True.

- n_clicks (number; default 0):
    An integer that represents the number of times    that this
    element has been clicked on.

- n_clicks_timestamp (number; default -1):
    An integer that represents the time (in ms since 1970)    at which
    n_clicks changed. This can be used to tell    which button was
    changed most recently.

- preventClose (boolean; default False):
    By default, the context menu is closed as soon as an item is
    clicked. Set this prop to control this behavior.

- selected (boolean; default False):
    Internal Prop: will be set from the surrounded context ContextMenu
    or SubMenu. If set to True the css class
    react-contextmenu-item--selected will be added to associated
    element.

- style (dict; optional):
    CSS properties."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, data=Component.UNDEFINED, clickData=Component.UNDEFINED, disabled=Component.UNDEFINED, preventClose=Component.UNDEFINED, selected=Component.UNDEFINED, divider=Component.UNDEFINED, n_clicks=Component.UNDEFINED, n_clicks_timestamp=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'clickData', 'data', 'disabled', 'divider', 'n_clicks', 'n_clicks_timestamp', 'preventClose', 'selected', 'style']
        self._type = 'MenuItem'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'clickData', 'data', 'disabled', 'divider', 'n_clicks', 'n_clicks_timestamp', 'preventClose', 'selected', 'style']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(MenuItem, self).__init__(children=children, **args)
