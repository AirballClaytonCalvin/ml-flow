# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class FlowChart(Component):
    """A FlowChart component.
Render a flow chart.

Keyword arguments:

- children (dict; optional):
    Supplementary components you can add to your main flow chart. It
    has to be    one of FlowBackground, FlowControls, FlowMiniMap.

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- arrowHeadColor (string; default "#b1b1b7"):
    The arrow head color.

- className (string; optional):
    Additional class name.

- clickData (dict; optional):
    Read-only prop. This is updated every time an element is clicked.
    Returns an element dictionary or None if nothing was clicked. e.g.
    `{id: \"2\", type: \"default\"}`.

- connectData (dict; optional):
    Read-only prop. This is updated every time an edge is connected to
    a node. Returns a dictionary     containing keys \"source\",
    \"target\", and more. e.g. `{source: \"1\", target: \"3\", ...}`.

- connectionLineStyle (string; optional):
    connection style as svg attributes.

- connectionLineType (string; optional):
    connection line type: one of \"default\", \"straight\", \"step\",
    \"smoothstep\".

- connectionMode (string; default 'strict'):
    Possible values are 'strict' (only source to target connections
    are possible) or 'loose' (source to source and target to target
    connections are allowed).

- defaultPosition (list; default [0, 0]):
    default Position.

- defaultZoom (number; default 1):
    default Zoom.

- deletableNodes (boolean; default True)

- deleteKeyCode (number | string; default "Backspace"):
    The key code for deleting a node.

- dragNode (dict; optional):
    Read-only prop. This is updated every time one or more nodes are
    dragged. Returns a dictionary representing a node     or None if
    nothing was selected. e.g.    `{id: \"2\", type: \"default\"}`.

- edgeUpdateData (dict; optional):
    Read-only prop. This is updated every time an edge was drag away
    from its original source or target.     Returns a dictionary
    containing keys \"oldEdge\" and \"newConnection\", e.g.
    `{newConnection: {source: \"1\", target: \"3\", ...}, oldEdge:
    {id: \"e1-2\", source: \"1\", target: \"2\", ...}}`.

- elements (list of dicts; optional):
    list of nodes and edges dictionaries.

    `elements` is a list of dicts with keys:

    - className (string; optional):
        Additional node className.

    - connectable (boolean; optional):
        Sets if node is connectable or not. Overwrites general
        nodesConnectable option.

    - data (dict; optional):
        Dictionary containing the node extended. (e.g: 'data':
        {'label': 'My node'}).

        `data` is a dict with keys:

        - handleNumber (number; optional)

        - iconClass (string; optional)

        - iconId (string; optional)

        - iconStyle (dict; optional)

        - sourceHandleIds (list; optional):
            Source handle ids. Used when have more than 1 handle The
            final value is composed by:
            {sourceHandleId}-target-{nodeId} Default: ['default'] ->
            default-source-{nodeId} Where nodeId is the id passed to
            the node.

        - sourceHandleNumber (number; optional)

        - sourcePosition (a value equal to: 'top', 'bottom', 'right', 'left'; optional)

        - style (dict; optional)

        - targetHandleIds (list; optional):
            Target handle ids. Used when have more than 1 handle The
            value is composed by:
            {targetHandleIds[i]}-target-{nodeId} Default: ['default']
            -> default-target-{nodeId} Where nodeId is the id passed
            to the node.

        - targetHandleNumber (number; optional)

        - targetPosition (a value equal to: 'top', 'bottom', 'right', 'left'; optional)

        - useIcon (boolean; optional)

    - dragHandle (string; optional)

    - draggable (boolean; optional):
        Sets if node is draggable or not. Overwrites general
        nodesDraggable option.

    - id (string; required):
        Node ID. Note this is not a dash component.

    - isHidden (boolean; optional):
        Sets node rendering. If True, the node will not be rendered.

    - position (dict; required):
        Node start position.

        `position` is a dict with keys:

        - x (number; required)

        - y (number; required)

    - selectable (boolean; optional):
        Sets if node is selectable or not. Overwrites general
        elementsSelectable option.

    - sourcePosition (a value equal to: 'top', 'left', 'right', 'bottom'; optional):
        Source handle position.

    - style (dict; optional):
        Node CSS properties.

    - targetPosition (a value equal to: 'top', 'left', 'right', 'bottom'; optional):
        Target handle position. Default: top.

    - type (a value equal to: 'input', 'default', 'output', 'customInput', 'customDefault', 'customOutput'; optional):
        Node type.

      Or dict with keys:

    - animated (boolean; optional):
        Define if edge is animated or not.

    - arrowHeadType (a value equal to: 'arrow', 'arrowclosed'; optional):
        Defines the arrowhead of the edge.

    - className (string; optional):
        Additional class name.

    - data (dict; optional):
        You can use this to pass data to your custom edges.

    - id (string; required):
        Edge ID. Note this is not a dash component.

    - isHidden (boolean; optional):
        Sets edge rendering. If True, the edge will not be rendered.

    - label (string; optional):
        Edge label text.

    - labelBgBorderRadius (number; optional):
        Label background border radius.

    - labelBgPadding (list; optional):
        Background rectangle padding. default: [2, 4].

    - labelBgStyle (dict; optional):
        CSS properties for the text background.

    - labelShowBg (boolean; optional):
        Show label background option.

    - labelStyle (dict; optional):
        CSS properties for the text.

    - markerEndId (string; optional):
        custom marker end url - if this is used arrowHeadType gets
        ignored.

    - source (string; required):
        An id of a node to be the source of the connection.

    - sourceHandle (string; optional):
        An id of a handle - you only need this when you have multiple
        handles using custom nodes.

    - style (dict; optional):
        CSS properties for the edge line path.

    - target (string; required):
        An id of a node to be the target of the connection.

    - targetHandle (string; optional):
        An id of a handle - you only need this when you have multiple
        handles using custom nodes.

    - type (a value equal to: 'default', 'straight', 'step', 'smoothstep', 'floating'; optional):
        Edge type. Default is bezier.

- elementsSelectable (boolean; default True):
    This applies to all elements. You can also change the behavior of
    a specific node with the selectable node option.

- fitOnLoad (boolean; default True):
    Whether to fit the view port so that all nodes are visible when
    the component is loaded.

- markerEndId (string; optional):
    Gets used as the marker-end attribute of the edges.

- maxZoom (number; default 2):
    max Zoom.

- minZoom (number; default 0.5):
    min Zoom.

- multiSelectionKeyCode (number | string; default "Meta"):
    While pressing the multiSelectionKeyCode you can select multiple
    nodes and edges with a click.

- nodesConnectable (boolean; default True):
    This applies to all nodes. You can also change the behavior of a
    specific node with the connectable node option.

- nodesDraggable (boolean; default True):
    This applies to all nodes. You can also change the behavior of a
    specific node with the draggable node option.

- onlyRenderVisibleElements (boolean; default False):
    only Render Visible Elements.

- panOnScroll (boolean; default False):
    Move the graph while keeping the zoomlevel using mousewheel or
    trackpad. Overwrites zoomOnScroll.

- panOnScrollMode (string; default 'free'):
    Possible values are 'free' (all directions), 'vertical' (only
    vertical) or 'horizontal' (only horizontal).

- panOnScrollSpeed (number; default 0.5):
    Controls how fast the canvas is moved while using the mousewheel.
    Only has an effect if panOnScroll is enabled.

- paneMoveable (boolean; default True):
    If set to False, panning and zooming is disabled.

- removeData (list of dicts; optional):
    Read-only prop. This is updated every time one or more elements
    are removed. When a node is removed, the connected    edges are
    also removed. An element can be removed by using the delete key,
    which is by default \"Backspace\" on windows and \"Delete\" on
    Mac,    but can be modified through the `deleteKeyCode` prop.
    Returns a list of element dictionaries or None if nothing was
    selected. e.g.     `[{id: \"2\", type: \"default\"},  {id:
    \"e1-2\", source: \"1\", target: \"2\"}, ...]`.

- selectData (list of dicts; optional):
    Read-only prop. This is updated every time one or more elements
    are selected, which means clicked, dragged    or highlighted by a
    click-and-drag box.    Returns a list of element dictionaries or
    None if nothing was selected. e.g.     `[{id: \"2\", type:
    \"default\"},  {id: \"e1-2\", source: \"1\", target: \"2\"},
    ...]`.

- selectNodesOnDrag (boolean; default True):
    Whether to select a node when it is dragged.

- selectionKeyCode (number | string; default "Shift"):
    While pressing the selectionKeyCode and dragging the mouse you can
    create a selection for multiple nodes and edges.

- snapGrid (list; default [15, 15]):
    snap Grid.

- snapToGrid (boolean; default False):
    snap To Grid.

- style (dict; default {"height": "400px"}):
    CSS properties.

- useFloatingEdges (boolean; default False):
    Defines if use floating edges style. If True will overwrite every
    edge in flowchart component.

- zoomOnDoubleClick (boolean; default True):
    Whether to zoom on double click.

- zoomOnScroll (boolean; default True):
    Zoom the graph in and out using the mousewheel or trackpad."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, elements=Component.UNDEFINED, useFloatingEdges=Component.UNDEFINED, deletableNodes=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, minZoom=Component.UNDEFINED, maxZoom=Component.UNDEFINED, defaultZoom=Component.UNDEFINED, defaultPosition=Component.UNDEFINED, snapToGrid=Component.UNDEFINED, snapGrid=Component.UNDEFINED, onlyRenderVisibleElements=Component.UNDEFINED, fitOnLoad=Component.UNDEFINED, clickData=Component.UNDEFINED, edgeUpdateData=Component.UNDEFINED, connectData=Component.UNDEFINED, selectData=Component.UNDEFINED, dragNode=Component.UNDEFINED, removeData=Component.UNDEFINED, nodesDraggable=Component.UNDEFINED, nodesConnectable=Component.UNDEFINED, elementsSelectable=Component.UNDEFINED, zoomOnScroll=Component.UNDEFINED, panOnScroll=Component.UNDEFINED, panOnScrollSpeed=Component.UNDEFINED, panOnScrollMode=Component.UNDEFINED, zoomOnDoubleClick=Component.UNDEFINED, selectNodesOnDrag=Component.UNDEFINED, paneMoveable=Component.UNDEFINED, connectionMode=Component.UNDEFINED, arrowHeadColor=Component.UNDEFINED, markerEndId=Component.UNDEFINED, connectionLineType=Component.UNDEFINED, connectionLineStyle=Component.UNDEFINED, deleteKeyCode=Component.UNDEFINED, selectionKeyCode=Component.UNDEFINED, multiSelectionKeyCode=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'arrowHeadColor', 'className', 'clickData', 'connectData', 'connectionLineStyle', 'connectionLineType', 'connectionMode', 'defaultPosition', 'defaultZoom', 'deletableNodes', 'deleteKeyCode', 'dragNode', 'edgeUpdateData', 'elements', 'elementsSelectable', 'fitOnLoad', 'markerEndId', 'maxZoom', 'minZoom', 'multiSelectionKeyCode', 'nodesConnectable', 'nodesDraggable', 'onlyRenderVisibleElements', 'panOnScroll', 'panOnScrollMode', 'panOnScrollSpeed', 'paneMoveable', 'removeData', 'selectData', 'selectNodesOnDrag', 'selectionKeyCode', 'snapGrid', 'snapToGrid', 'style', 'useFloatingEdges', 'zoomOnDoubleClick', 'zoomOnScroll']
        self._type = 'FlowChart'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'arrowHeadColor', 'className', 'clickData', 'connectData', 'connectionLineStyle', 'connectionLineType', 'connectionMode', 'defaultPosition', 'defaultZoom', 'deletableNodes', 'deleteKeyCode', 'dragNode', 'edgeUpdateData', 'elements', 'elementsSelectable', 'fitOnLoad', 'markerEndId', 'maxZoom', 'minZoom', 'multiSelectionKeyCode', 'nodesConnectable', 'nodesDraggable', 'onlyRenderVisibleElements', 'panOnScroll', 'panOnScrollMode', 'panOnScrollSpeed', 'paneMoveable', 'removeData', 'selectData', 'selectNodesOnDrag', 'selectionKeyCode', 'snapGrid', 'snapToGrid', 'style', 'useFloatingEdges', 'zoomOnDoubleClick', 'zoomOnScroll']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(FlowChart, self).__init__(children=children, **args)
