# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Dropdown(Component):
    """A Dropdown component.


Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- className (string; default ''):
    Additional className to dropdown parent div.

- isOpen (boolean; default False):
    Dropdown property to know if it is open.

- label (string; optional):
    Dropdown current label.

- options (list of dicts; optional):
    Dropdown options elements. You can choosen between passing a FA
    className or a path.  If className is passed, the dropdown will
    render a HTML icon with the className, else if path is passed  the
    component will be rendered with a HTML image with src=path.

    `options` is a list of dicts with keys:

    - className (string; optional):
        Additional className to option div.

    - icon_position (a value equal to: 'right', 'left'; optional):
        Position relative to label where icon will be rendered.

    - icon_style (dict; optional):
        CSS properties for icon.  It's important  to note that if
        using an icon the customizable properties should be relative
        to a HTML <i> element and if using an image relative to a HTML
        <img> element.

    - label (string; required):
        Option label to be rendered.

    - path (string; optional):
        Path used as source if icon is an image.

    - style (dict; optional):
        CSS properties for option wrapper div.

    - type (a value equal to: '', 'placeholder'; optional):
        Used to define if an option is a placeholder.

    - value (string; required):
        Option value.

- renderDownCaret (boolean; default False):
    Use down caret in component.

- style (dict; optional):
    Dropdown header wrapper (placeholder menu) CSS properties.

- value (string; optional):
    Dropdown current value.

- wrapperClassName (string; default ''):
    Additional className to dropdown wrapper div.

- wrapperStyle (dict; optional):
    Dropdown wrapper CSS properties."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, wrapperClassName=Component.UNDEFINED, wrapperStyle=Component.UNDEFINED, isOpen=Component.UNDEFINED, options=Component.UNDEFINED, value=Component.UNDEFINED, label=Component.UNDEFINED, renderDownCaret=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'className', 'isOpen', 'label', 'options', 'renderDownCaret', 'style', 'value', 'wrapperClassName', 'wrapperStyle']
        self._type = 'Dropdown'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'className', 'isOpen', 'label', 'options', 'renderDownCaret', 'style', 'value', 'wrapperClassName', 'wrapperStyle']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Dropdown, self).__init__(**args)
