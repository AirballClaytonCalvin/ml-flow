# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Calendar(Component):
    """A Calendar component.
The calendar component

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- allDayAccessor (string; default 'allDay'):
    Dictionary key corresponding to the event \"allDay\" attribute.
    It determines whether the event should be considered an \"all
    day\" event and ignore time.    The dictionary value corresponding
    to that key must be a boolean.

- className (string; optional):
    Additional class name.

- culture (string; default 'en-US'):
    Specify a specific culture code for the Calendar.

- date (string; optional):
    The current date value of the calendar. Determines the visible
    view range.    If `date` is omitted then the result of `getNow` is
    used; otherwise the    current date is used.

- defaultDate (string; optional):
    Date to start the calendar.

- defaultView (a value equal to: 'month', 'week', 'work_week', 'day', 'agenda'; optional):
    The initial view set for the Calendar.

- deleteKey (string; default 'delete'):
    Key to be used to delete an event.

- dragAndDropEvents (boolean; default False):
    Set if events can be dragged.

- drilldownView (string; default 'day'):
    The string name of the destination view for drill-down actions,
    such    as clicking a date header, or the truncated events links.
    If    `getDrilldownView` is also specified it will be used
    instead.     Set to `None` to disable drill-down actions.
    Example:        ```python    Calendar(drilldownView=\"agenda\")
    ```.

- endAccessor (string; default 'end'):
    Dictionary key corresponding to the end date/time of the event.
    The dictionary value corresponding to that key must `datetime`
    object.

- events (list of dicts; optional):
    A list of event dictionaries to display on the calendar. Events
    dictionaries    can be any shape, as long as the Calendar knows
    how to retrieve the    following details of the event:      -
    start time      - end time      - title      - whether its an
    \"all day\" event or not (bool). Default: \"allDay\"      - any
    resource the event may be related to (str). Default: \"resource\"
    Each of these properties can be customized or generated
    dynamically by    setting the various \"accessor\" props. Without
    any configuration the default    event should be a list of
    dictionary in the following format:.

    `events` is a list of dicts with keys:

    - allDay (number | boolean; optional):
        Whether its an \"all day\" event or not.

    - end (string; required):
        Event end date.

    - id (string | number; optional):
        Event ID.

    - resource (boolean | number | string | dict | list; optional):
        Any resource the event may be a related too.

    - start (string; required):
        Event start date.

    - title (string; required):
        Event title.

- length (number; default 30):
    Determines the end date from date prop in the agenda view    date
    prop + length (in number of days) = end date.

- longPressThreshold (number; default 250):
    Specifies the number of miliseconds the user must press and hold
    on the screen for a touch    to be considered a \"long press.\"
    Long presses are used for time slot selection on touch    devices.

- max (string; optional):
    Constrains the maximum _time_ of the Day and Week views. Should be
    a `datetime.time` object.

- min (string; optional):
    Constrains the minimum _time_ of the Day and Week views. Should be
    a `datetime.time` object.

- popup (boolean; default False):
    Show truncated events in an overlay when you click the \"+_x_
    more\" link.

- popupOffset (number | dict; optional):
    Distance in pixels, from the edges of the viewport, the \"show
    more\" overlay should be positioned.     If given a number, the
    offset will be adjusted for both `x` and `y`. If given a
    dictionary, the keys    must be `x` and `y`, indicating the
    respective offset along the axes.      Use one of the two
    following ways to calculate offsets:     ```python
    Calendar(popupOffset=30)    Calendar(popupOffset={x: 30, y: 20})
    ```.

- resourceAccessor (string; default 'resourceId'):
    Returns the id of the `resource` that the event is a member of.
    This    id should match at least one resource in the `resources`
    array.

- resourceIdAccessor (string; default 'id'):
    Provides a unique identifier for each resource in the `resources`
    array.

- resourceTitleAccessor (string; default 'title'):
    Provides a human readable name for the resource dictionary, used
    in headers.

- resources (list of dicts; optional):
    A list of resource dictionaries that map events to a specific
    resource.    Resource dictionaries, like events, can be any shape
    or have any properties,    but should be uniquly identifiable via
    the `resourceIdAccessor`, as    well as a \"title\" or name as
    provided by the `resourceTitleAccessor` prop.

- rtl (boolean; optional):
    Switch the calendar to a `right-to-left` read direction.

- scrollToTime (string; optional):
    Determines how far down the scroll pane is initially scrolled
    down. Should be a `datetime` object.

- selectable (a value equal to: true, false, 'ignoreEvents'; default True):
    Allows mouse selection of ranges of dates/times.     The
    'ignoreEvents' option prevents selection code from running when a
    drag begins over an event. Useful when you want custom event click
    or drag    logic.

- selected (dict; optional):
    The selected event, if any.

- selectedSlot (dict; optional):
    Selected slot object.

    `selectedSlot` is a dict with keys:

    - end (optional):
        Selected slot end datetime.

    - slots (list; optional):
        Array of datetime selected slots.

    - start (optional):
        Selected slot start datetime.

- showAllEvents (boolean; optional):
    Displays all events on the month view instead of    having some
    hidden behind +{count} more. This will    cause the rows in the
    month view to be scrollable if    the number of events exceed the
    height of the row.

- showMultiDayTimes (boolean; optional):
    Support to show multi-day events with specific start and end times
    in the    main time grid (rather than in the all day header).
    **Note: This may cause calendars with several events to look very
    busy in    the week and day views.**.

- startAccessor (string; default 'start'):
    Dictionary key corresponding to the start date/time of the event.
    The dictionary value corresponding to that key must `datetime`
    object.

- step (number; default 30):
    Determines the selectable time increments in week and day views,
    in minutes.

- style (dict; optional):
    CSS properties.

- timeslots (number; optional):
    The number of slots per \"section\" in the time grid views. Adjust
    with `step`    to change the default of 1 hour long groups, with
    30 minute slots.

- titleAccessor (string; default 'title'):
    Dictionary key corresponding to the event title, used to display
    event information.     The dictionary value corresponding to that
    key must be a string.

- titleWindowOnSelectSlot (boolean; default False):
    Define if prompt title window on select slot.

- toolbar (boolean; default True):
    Determines whether the toolbar is displayed.

- tooltipAccessor (string; default 'title'):
    Dictionary key corresponding to the event tooltip. The dictionary
    value corresponding     to that key must be a string. Removes the
    tooltip if `None`.

- view (a value equal to: 'month', 'week', 'work_week', 'day', 'agenda'; optional):
    The current view of the calendar.

- views (list of strings; default ['month', 'week', 'day', 'agenda', 'work_week']):
    A list of built-in view names to allow the calendar to display.
    accepts either a list of builtin view names,        ```python
    Calendar(views=['month', 'day', 'agenda'])    ```."""
    @_explicitize_args
    def __init__(self, date=Component.UNDEFINED, defaultDate=Component.UNDEFINED, id=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, titleWindowOnSelectSlot=Component.UNDEFINED, selectedSlot=Component.UNDEFINED, view=Component.UNDEFINED, defaultView=Component.UNDEFINED, events=Component.UNDEFINED, titleAccessor=Component.UNDEFINED, tooltipAccessor=Component.UNDEFINED, allDayAccessor=Component.UNDEFINED, startAccessor=Component.UNDEFINED, endAccessor=Component.UNDEFINED, resourceAccessor=Component.UNDEFINED, resources=Component.UNDEFINED, resourceIdAccessor=Component.UNDEFINED, resourceTitleAccessor=Component.UNDEFINED, showAllEvents=Component.UNDEFINED, selected=Component.UNDEFINED, views=Component.UNDEFINED, drilldownView=Component.UNDEFINED, length=Component.UNDEFINED, toolbar=Component.UNDEFINED, popup=Component.UNDEFINED, popupOffset=Component.UNDEFINED, selectable=Component.UNDEFINED, longPressThreshold=Component.UNDEFINED, step=Component.UNDEFINED, timeslots=Component.UNDEFINED, rtl=Component.UNDEFINED, showMultiDayTimes=Component.UNDEFINED, min=Component.UNDEFINED, max=Component.UNDEFINED, scrollToTime=Component.UNDEFINED, culture=Component.UNDEFINED, deleteKey=Component.UNDEFINED, dragAndDropEvents=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'allDayAccessor', 'className', 'culture', 'date', 'defaultDate', 'defaultView', 'deleteKey', 'dragAndDropEvents', 'drilldownView', 'endAccessor', 'events', 'length', 'longPressThreshold', 'max', 'min', 'popup', 'popupOffset', 'resourceAccessor', 'resourceIdAccessor', 'resourceTitleAccessor', 'resources', 'rtl', 'scrollToTime', 'selectable', 'selected', 'selectedSlot', 'showAllEvents', 'showMultiDayTimes', 'startAccessor', 'step', 'style', 'timeslots', 'titleAccessor', 'titleWindowOnSelectSlot', 'toolbar', 'tooltipAccessor', 'view', 'views']
        self._type = 'Calendar'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'allDayAccessor', 'className', 'culture', 'date', 'defaultDate', 'defaultView', 'deleteKey', 'dragAndDropEvents', 'drilldownView', 'endAccessor', 'events', 'length', 'longPressThreshold', 'max', 'min', 'popup', 'popupOffset', 'resourceAccessor', 'resourceIdAccessor', 'resourceTitleAccessor', 'resources', 'rtl', 'scrollToTime', 'selectable', 'selected', 'selectedSlot', 'showAllEvents', 'showMultiDayTimes', 'startAccessor', 'step', 'style', 'timeslots', 'titleAccessor', 'titleWindowOnSelectSlot', 'toolbar', 'tooltipAccessor', 'view', 'views']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Calendar, self).__init__(**args)
