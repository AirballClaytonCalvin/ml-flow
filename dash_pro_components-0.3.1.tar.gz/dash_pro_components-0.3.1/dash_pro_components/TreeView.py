# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class TreeView(Component):
    """A TreeView component.
Displays an interactive treeview of your files, with support for drag-and-drop and themes.

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- canDrag (boolean; default True):
    Return False from callback to prevent node from dragging, by
    hiding the drag handle. Set prop to False to disable dragging on
    all nodes.

- className (string; optional):
    Additional class name.

- maxDepth (number; optional):
    Maximum depth nodes can be inserted at. Defaults to infinite.

- onlyExpandSearchedNodes (boolean; default False):
    Only expand the nodes that match searches. Collapses all other
    nodes.

- searchQuery (string; optional):
    Titles and subtitles matching this prop will be highlighted.

- style (dict; default { height: 400 }):
    CSS properties. Style applied to the container wrapping the tree.

- treeData (list of dicts; required):
    An array of nested objects containing each tree node and it's
    respective children.

    `treeData` is a list of dicts with keys:

    - children (list; optional):
        An array of child nodes belonging to the node.

    - expanded (boolean; optional):
        Shows children of the node if True, or hides them if False.
        Defaults to False.

    - subtitle (string; optional):
        Is a secondary label for the node.

    - title (string; optional):
        Is the primary label for the node."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, treeData=Component.REQUIRED, canDrag=Component.UNDEFINED, searchQuery=Component.UNDEFINED, onlyExpandSearchedNodes=Component.UNDEFINED, maxDepth=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'canDrag', 'className', 'maxDepth', 'onlyExpandSearchedNodes', 'searchQuery', 'style', 'treeData']
        self._type = 'TreeView'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'canDrag', 'className', 'maxDepth', 'onlyExpandSearchedNodes', 'searchQuery', 'style', 'treeData']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in ['treeData']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(TreeView, self).__init__(**args)
