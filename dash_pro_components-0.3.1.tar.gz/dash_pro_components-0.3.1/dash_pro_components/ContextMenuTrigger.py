# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class ContextMenuTrigger(Component):
    """A ContextMenuTrigger component.


Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    A Dash component for which you want to customize the context menu.

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- className (string; optional):
    Additional class name.

- disable (boolean; optional):
    Ignore right clicks and display the default browser context menu.

- holdToDisplay (number; default 1000):
    This is applicable only for touch screens. The time (in ms) for
    which, user has to hold down his/her     finger before the menu is
    shown. Note: To disable the long press trigger on left-click just
    set a     negative holdToDisplay value such as -1.

- style (dict; optional):
    CSS properties.

- target (string; optional):
    The ID of the ContextMenu component that should appear when this
    target is triggered."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, target=Component.UNDEFINED, holdToDisplay=Component.UNDEFINED, disable=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'disable', 'holdToDisplay', 'style', 'target']
        self._type = 'ContextMenuTrigger'
        self._namespace = 'dash_pro_components'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'disable', 'holdToDisplay', 'style', 'target']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}
        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(ContextMenuTrigger, self).__init__(children=children, **args)
