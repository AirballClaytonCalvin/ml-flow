# Dash Pro Components

Pro Components is a package of Dash components for complex, feature-rich and performant Dash apps.

* [API References](https://dash.plotly.com/dash-pro-components)
* [Gallery](./docs/GALLERY.md)

# Installation & Setup

#### Install Latest Release
1. (optional) Set up and active a virtual environment (Varies based on your shell) :
```bash
python3 -m venv venv
source venv/bin/activate
```
2. Install the latest released version
```bash
pip install git+https://github.com/plotly/pro-components.git@v0.0.3
```

#### Clone and Install development version
1. Clone this repository
```bash
git clone https://github.com/plotly/pro-components.git
```
2. Enter project folder
```bash
cd pro-componentss
```
3. (optional) Set up and active a virtual environment (Varies based on your shell) :
```bash
python3 -m venv venv
source venv/bin/activate
```
4. Install the local package
```bash
pip install -e .
```
At this point you should have the package installed in your environment


# Getting started for contributors
1. Clone this repository
```bash
git clone https://github.com/plotly/pro-components.git
```
2. Enter project folder
```bash
cd pro-componentss
```
3. (optional) Set up and active a virtual environment (Varies based on your shell) :
```bash
python3 -m venv venv
source venv/bin/activate
```
4. Install python requirements
```bash
pip install -r requirements.txt
```

5. Install JS requirements
```bash
npm install
```

6. Build the package
```bash
npm run build
```

7. Install local builded version
```bash
pip install -e .
```

